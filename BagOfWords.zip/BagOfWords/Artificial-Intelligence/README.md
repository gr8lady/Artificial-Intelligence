# Artificial-Intelligence
my homeworks and codes will be placed here
